#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "student.h"
#include "file.h"

int main(int argc, char *argv[]) {

    struct Student *head = NULL;
    int choice;

    if(argc > 1 && strcmp(argv[1],"load")==0)
        loadBinary(&head);

    while(1) {

        printf("\n1.Add\n2.Display\n3.Search by ID\n4.Sort by GPA\n5.Save\n6.Update GPA (File)\n7.Exit\n");
        scanf("%d",&choice);

        if(choice==1)
            addStudent(&head);

        else if(choice==2)
            displayStudents(head);

        else if(choice==3) {
            int id;
            printf("Enter ID: ");
            scanf("%d",&id);
            struct Student *found = searchStudent(head, compareById, &id);
            if(found)
                printf("Found: %s GPA: %.2f\n", found->name, found->gpa);
            else
                printf("Not Found\n");
        }

        else if(choice==4)
            sortList(&head, sortByGPA);

        else if(choice==5)
            saveBinary(head);

        else if(choice==6) {
            int id;
            float gpa;
            printf("ID: "); scanf("%d",&id);
            printf("New GPA: "); scanf("%f",&gpa);
            updateStudentGPA(id,gpa);
        }

        else if(choice==7)
            break;
    }

    return 0;
}