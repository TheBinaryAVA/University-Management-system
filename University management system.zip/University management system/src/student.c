#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

void addStudent(struct Student **head) {
    struct Student *newNode = malloc(sizeof(struct Student));

    printf("Enter ID: ");
    scanf("%d", &newNode->id);

    printf("Enter Name: ");
    scanf(" %[^\n]", newNode->name);

    int sem, sub;
    printf("Enter number of semesters: ");
    scanf("%d", &sem);

    printf("Enter subjects per semester: ");
    scanf("%d", &sub);

    newNode->gpa = calculateGPA(sem, sub);

    newNode->next = *head;
    *head = newNode;
}

void displayStudents(struct Student *head) {
    while(head) {
        printf("\nID: %d", head->id);
        printf("\nName: %s", head->name);
        printf("\nGPA: %.2f\n", head->gpa);
        head = head->next;
    }
}

/* Dynamic 2D Allocation */
float calculateGPA(int semesters, int subjects) {
    int **marks = malloc(semesters * sizeof(int*));

    for(int i=0;i<semesters;i++)
        marks[i] = malloc(subjects * sizeof(int));

    float total = 0;
    int count = 0;

    for(int i=0;i<semesters;i++) {
        for(int j=0;j<subjects;j++) {
            printf("Marks [Sem %d Sub %d]: ", i+1, j+1);
            scanf("%d", &marks[i][j]);
            total += marks[i][j];
            count++;
        }
    }

    for(int i=0;i<semesters;i++)
        free(marks[i]);
    free(marks);

    return total / count;
}

/* SEARCH USING FUNCTION POINTER */

int compareById(struct Student *s, void *key) {
    return s->id == *(int*)key;
}

int compareByName(struct Student *s, void *key) {
    return strcmp(s->name, (char*)key) == 0;
}

struct Student* searchStudent(struct Student *head,
                               CompareFunc cmp,
                               void *key) {
    while(head) {
        if(cmp(head, key))
            return head;
        head = head->next;
    }
    return NULL;
}

/* SORT USING FUNCTION POINTER */

int sortById(struct Student *a, struct Student *b) {
    return a->id > b->id;
}

int sortByGPA(struct Student *a, struct Student *b) {
    return a->gpa < b->gpa;
}

void sortList(struct Student **head, SortFunc cmp) {
    struct Student *i, *j;

    for(i=*head; i!=NULL; i=i->next) {
        for(j=i->next; j!=NULL; j=j->next) {
            if(cmp(i,j)) {
                int tempId = i->id;
                char tempName[50];
                float tempGPA = i->gpa;

                strcpy(tempName, i->name);

                i->id = j->id;
                strcpy(i->name, j->name);
                i->gpa = j->gpa;

                j->id = tempId;
                strcpy(j->name, tempName);
                j->gpa = tempGPA;
            }
        }
    }
}