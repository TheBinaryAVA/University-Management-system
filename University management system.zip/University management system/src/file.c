#include <stdio.h>
#include <stdlib.h>
#include "file.h"

void saveBinary(struct Student *head) {
    FILE *fp = fopen("data/students.dat","wb");
    while(head) {
        fwrite(head, sizeof(struct Student),1,fp);
        head = head->next;
    }
    fclose(fp);
}

void loadBinary(struct Student **head) {
    FILE *fp = fopen("data/students.dat","rb");
    if(!fp) return;

    struct Student temp;

    while(fread(&temp,sizeof(struct Student),1,fp)) {
        struct Student *newNode = malloc(sizeof(struct Student));
        *newNode = temp;
        newNode->next = *head;
        *head = newNode;
    }

    fclose(fp);
}

/* RANDOM ACCESS UPDATE USING fseek */

void updateStudentGPA(int id, float newGPA) {

    FILE *fp = fopen("data/students.dat","rb+");
    if(!fp) return;

    struct Student s;

    while(fread(&s,sizeof(struct Student),1,fp)) {

        if(s.id == id) {
            fseek(fp, -sizeof(struct Student), SEEK_CUR);
            s.gpa = newGPA;
            fwrite(&s,sizeof(struct Student),1,fp);
            break;
        }
    }

    fclose(fp);
}