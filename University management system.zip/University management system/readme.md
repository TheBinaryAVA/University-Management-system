# 🎓 University Management System (C)

A modular, file-based University Management System built in C demonstrating advanced core C concepts including dynamic memory allocation, function pointers, linked lists, and binary file handling.

---

## 🚀 Features

- ✅ Linked List based Student Management
- ✅ Dynamic GPA Calculation using 2D memory allocation
- ✅ Function Pointer based Searching
- ✅ Function Pointer based Sorting
- ✅ Binary File Storage
- ✅ Random File Access using `fseek()`
- ✅ Command Line Argument Support
- ✅ Modular Multi-file Architecture
- ✅ Makefile Build System

---

## 🧠 Concepts Covered

### Module 1 – Core C
- Structure of C Program
- Variables and Data Types
- Operators and Precedence
- Control Structures
- 1D and 2D Arrays
- Strings
- Functions
- Call by Value and Call by Reference
- Recursion
- Storage Classes
- Scope and Lifetime

### Module 2 – Pointers, Structures & Files
- Pointer Arithmetic
- Pointers with Arrays and Functions
- Function Pointers
- Dynamic Memory Allocation (`malloc`, `free`)
- Structures and Nested Structures
- Self-Referential Structures (Linked List)
- Unions
- Bit Fields
- Pointers to Structures
- Text and Binary File Handling
- Random File Access using `fseek`
- Command Line Arguments

---


